
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.CRC32;
import java.nio.*;

public class sender {

	public static final int MSS = 576; // max segment size
	public static final int HEADERSIZE = 20;
	public static final short WINDOWSIZE = 1;
	public static final int TIMEOUTINTERVAL = 1000000;
	
	public static void main( String[] args ) throws IOException {
		
		if ( args.length != 5 ) {
			System.out.println("Usage: java sender <filename> <remote_IP> <remote_port> <ack_port_num> <log_filename>");
			return;
		}
		
		FileWriter fw = null;
		BufferedWriter bw = null;
		if ( args[4] != "stdout" ) {
			File logfile = new File( args[4] );
			if ( !logfile.exists() ) {
				logfile.createNewFile();
			}
			
			fw = new FileWriter( logfile.getAbsoluteFile() );
			bw = new BufferedWriter( fw );
		}
		
		FileInputStream in = null;
		try {
			in = new FileInputStream( args[0] );
		} catch ( FileNotFoundException f  ) {
			System.out.println("File not found!");
			return;
		}
		
		
		
		// read file into segments in memory
		int filesize = (int) in.getChannel().size();
		int numberOfSegments;
		if ( filesize < MSS ) {
			numberOfSegments = 1;
		} else if ( (filesize % MSS) > 0  ) {
			numberOfSegments = (filesize / MSS)+1;
		} else {
			numberOfSegments = (filesize / MSS);
		}
		
		byte[][] segments = new byte[ numberOfSegments ][ MSS ];
		for ( int i = 0; i < numberOfSegments; i++ ) {
			in.read( segments[i] );
		}
		
		// listening socket for sender
		DatagramSocket socket = new DatagramSocket( Integer.parseInt(args[3]) );

		// address packet to receiver
		InetAddress remote_IP = InetAddress.getByName( args[1] );
		short remote_port = Short.parseShort( args[2] );
		
		// create byte[] for header
		byte[] source_port = ByteBuffer.allocate(2).putShort( Short.parseShort(args[3]) ).array();
		byte[] dest_port = ByteBuffer.allocate(2).putShort(remote_port).array();
		byte[] data_offset = new byte[1];
		data_offset[0] = (byte) 5;
		byte[] window_size = ByteBuffer.allocate(2).putShort( WINDOWSIZE ).array();
		byte[] pack = null;
		byte[] seq_num = null;
		byte[] ack_num = null;
		byte[] fin_num = null;
		byte[] pseudoheader = null;
		byte[] checksumData = null;
		byte[] checksum = null;
		
		int seqNum = 0;
		int ackNum = seqNum + 10;
		int finNum = 0;
		CRC32 crc = new CRC32();
	
		
		int totalBytesSent = 0;
		int segsSent = 0;
		int segsResent = 0;
		
		boolean keepListening;
		
		// send each packet in segments array
		ServerSocket serverSocket = new ServerSocket( Integer.parseInt( args[3] ) );
		Socket clientSocket = null;
		BufferedReader ackin = null;
		for ( int i = 0; i < numberOfSegments; i++ ) {
			keepListening = true;
			// create packet with header
			pack = new byte[ HEADERSIZE + MSS ];
			seq_num = ByteBuffer.allocate(4).putInt(seqNum).array();
			ack_num = ByteBuffer.allocate(4).putInt(ackNum).array();
			
			fin_num = new byte[1];
			if ( i < numberOfSegments - 1 ) {
				fin_num[0] = (byte) 0;
			} else {
				fin_num[0] = (byte) 1;
			}
			
			System.arraycopy( source_port, 0, pack, 0, source_port.length );
			System.arraycopy( dest_port, 0, pack, source_port.length, dest_port.length );
			System.arraycopy( seq_num, 0, pack, 4, seq_num.length );
			System.arraycopy( ack_num, 0, pack, 8, ack_num.length );
			System.arraycopy( data_offset, 0, pack, 12, data_offset.length );
			System.arraycopy( fin_num, 0, pack, 13, fin_num.length );
			System.arraycopy( window_size, 0, pack, 14, window_size.length );

			// pseudo-header that excludes checksum
			pseudoheader = new byte[ 12 ];
			System.arraycopy( pack, 0, pseudoheader, 0, 12);
			
			// calculate checksum on pseudo-header+data
			checksumData = new byte[ 12 + MSS ];
			System.arraycopy( pseudoheader, 0, checksumData, 0, 12 );
			System.arraycopy( segments[i], 0, checksumData, 12, segments[i].length );
			crc.update( checksumData );
			checksum = ByteBuffer.allocate(4).putInt( (int) crc.getValue() ).array();
			
			// add checksum to complete header + segment = pack
			System.arraycopy( checksum, 0, pack, 16, checksum.length );
			System.arraycopy( segments[i], 0, pack, HEADERSIZE, segments[i].length );
			
		/**	for ( byte b: pack ) {
				System.out.print( Integer.toBinaryString( b&255 | 256 ).substring(1) +" ");
			}  **/
			
			//send pack
			DatagramPacket packet = new DatagramPacket( pack, pack.length, remote_IP, remote_port );
			socket.send( packet );
			totalBytesSent = totalBytesSent + packet.getData().length; 
			segsSent++;
			long sentTime = System.currentTimeMillis();

			
			// wait to receive ACK
			serverSocket.setSoTimeout( 2 * 1000 );
			while ( keepListening ) {
				try {
					clientSocket = serverSocket.accept();
					long RTT = System.currentTimeMillis() - sentTime;
					keepListening = false;
					ackin = new BufferedReader( new InputStreamReader( clientSocket.getInputStream() ) );
					String ackLine = ackin.readLine();
				
					// log to logfile
					if ( args[4] == "stdout" ) {
						System.out.println( System.currentTimeMillis()+ ", " + args[3]
								+ ", "+ args[2]+", "+ seqNum+", " +ackNum+", RTT: "+ RTT  );
					} else {
						bw.write(  System.currentTimeMillis()+ ", " + args[3]
								+ ", "+ args[2]+", "+ seqNum+", " +ackNum+", RTT: "+ RTT +"\n" );
					}
										
					if ( Integer.parseInt( ackLine ) == ackNum  ) {  // if ACK matches
						seqNum++;
						ackNum++;
					} else {
						keepListening = true;
					}
				
					
				} catch ( InterruptedIOException e ) {
					socket.send( packet );
					totalBytesSent = totalBytesSent + packet.getData().length;
					segsSent++;
					segsResent++;
				}
			}
		
			if ( i == numberOfSegments-1 ) {
				System.out.println( "Delivery completed successfully" );
			}
			
		} //end for
		
		System.out.println( "Total bytes sent = "+totalBytesSent );
		System.out.println( "Segments sent = "+segsSent );
		System.out.println( "Segments retrasmitted = "+segsResent );
		
		
		bw.close();
		in.close();
		ackin.close();
		socket.close();
		
	} //end main

}








