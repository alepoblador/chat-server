#!/bin/sh

rm *.class
rm *.txt
javac *.java 2>&1
