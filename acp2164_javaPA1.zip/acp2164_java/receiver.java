
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.CRC32;
import java.nio.*;

public class receiver {
	
	public static final int MSS = 576; // max segment size
	public static final int HEADERSIZE = 20;
	public static final int TIMEOUTINTERVAL = 1000000;
	
	public static void main( String[] args ) throws IOException {
		
		if ( args.length != 5 ) {
			System.out.println("Usage: java receiver <filename> <listening_port> <sender_IP> <sender_port> <log_filename>");
			return;
		}
		
		// socket at listening port of receiver
		DatagramSocket socket = new DatagramSocket( Integer.parseInt(args[1]) );
		
		FileWriter fw= null;
		BufferedWriter bw = null;
		if ( args[4] != "stdout" ) {
			File logfile = new File( args[4] );
			if ( !logfile.exists() ) {
				logfile.createNewFile();
			}
			
			fw = new FileWriter( logfile.getAbsoluteFile() );
			bw = new BufferedWriter( fw );
		}
		
		int expectedSeq = 0;
		
		FileOutputStream out = null;
		PrintWriter ackout = null;
		CRC32 crc = new CRC32();
		while ( true ) {
			// wait to receive packet
			byte[] segment = new byte[ HEADERSIZE + MSS ];
			DatagramPacket packet = new DatagramPacket( segment, segment.length );
			socket.receive(packet);
			
			byte finSignal = packet.getData()[13];
			ByteBuffer bb = ByteBuffer.wrap( packet.getData() );
			int rcvdSeq = bb.getInt( 4 );
			int rcvdAck = bb.getInt( 8 );
			int rcvdChecksum = bb.getInt( 16 );

	
			// calculate checksum from received packet
			byte[] checksumData = new byte[12+MSS];
			bb.get( checksumData, 0, 12 );
			bb.position( 20 );
			bb.get( checksumData, 12, MSS );
			crc.update( checksumData );
			int calcChecksum = (int) crc.getValue();

			// separate header from segments, write segments to file
			byte[] pack = packet.getData();
			byte[] header = new byte[ HEADERSIZE ];
			byte[] segData = new byte[ MSS ];
			System.arraycopy( pack, 0, header, 0, HEADERSIZE);
			System.arraycopy( pack, HEADERSIZE, segData, 0, MSS  );
			
			out = new FileOutputStream ( args[0], true );
			out.write( segData );
			
			Socket ackSocket = null;
			ackSocket = new Socket( args[2], Integer.parseInt(args[3]) );
			ackout = new PrintWriter( ackSocket.getOutputStream(), true );
			
			if ( rcvdSeq == expectedSeq ) {
								
			/**	if ( rcvdPackets.get( expectedSeq ) == 1 ) {
					// discard duplicate
					System.out.println("DUPLICATE DETECTED!");
					break;			
				} else {
					byte flag = 1;
					rcvdPackets.add( expectedSeq, flag );
				} **/
				
				if ( rcvdChecksum == calcChecksum ) {
					// send back ACK via TCP
					ackout.println( rcvdAck );
					expectedSeq++;
					
					
					// log to logfile
					if ( args[4] == "stdout" ) {
						System.out.println( System.currentTimeMillis()+ ", " + packet.getPort()
								+ ", "+ args[1]+", "+ rcvdSeq+", " +rcvdAck);
					} else {
						bw.write(  System.currentTimeMillis()+ ", " + packet.getPort()
								+ ", "+ args[1]+", "+ rcvdSeq+", " +rcvdAck+"\n" );
					}
					
					
				} else { 							   // packet is corrupt
				}
				
			}
			
		
			
			// exit while loop if FIN signal = 1
			if ( finSignal == 1 ) 
				break;
		}		
	
	
		bw.close();
		out.close();
		ackout.close();
		socket.close();
		
		
	}
	
	
}
